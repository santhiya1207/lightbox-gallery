import React from 'react';
import SimpleReactLightbox from 'simple-react-lightbox';
import './App.css';
import { MainComponent } from './MainComponent';


function App() {
  return (  
    <SimpleReactLightbox>
       <MainComponent /> 
    </SimpleReactLightbox>
  );
}

export default App;
