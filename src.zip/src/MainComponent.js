import React from 'react';
import { SRLWrapper } from "simple-react-lightbox";
import './MainComponent.css';
export const MainComponent = () => {

    return (
        <SRLWrapper>
            <h1 style={{textAlign: "center"}}>Image Gallery</h1>
            <div style={{width: "100%", display: 'flex', flexWrap: "wrap", height: "100vh",margin: "auto"}}>
                <div style={{width: "30%", margin: "auto" }}>
                    <img src='./images/img1.jpg' style={{width: "100%"}} />
                </div>
                <div style={{width: "30%", margin: "auto" }}>
                    <img src='./images/img2.jpg' style={{width: "100%"}} />
                </div>
                <div style={{width: "30%", margin: "auto" }}>
                    <img src='./images/img3.jpg' style={{width: "100%"}} />
                </div>
                <div style={{width: "30%", margin: "auto" }}>
                    <img src='./images/img4.jpg' style={{width: "100%"}} />
                </div>
                <div style={{width: "30%", margin: "auto" }}>
                    <img src='./images/img5.jpg' style={{width: "100%"}} />
                </div>
                <div style={{width: "30%", margin: "auto" }}>
                    <img src='./images/img6.jpg' style={{width: "100%"}} />
                </div>
                <div style={{width: "30%", margin: "auto" }}>
                    <img src='./images/img7.jpg' style={{width: "100%"}} />
                </div>
                <div style={{width: "30%", margin: "auto" }}>
                    <img src='./images/img8.jpg' style={{width: "100%"}} />
                </div>
                <div style={{width: "30%", margin: "auto" }}>
                    <img src='./images/img9.jpg' style={{width: "100%"}} />
                </div>
                <div style={{width: "30%", margin: "auto" }}>
                    <img src='./images/img10.jpg' style={{width: "100%"}} />
                </div>
                <div style={{width: "30%", margin: "auto" }}>
                    <img src='./images/img11.jpg' style={{width: "100%"}} />
                </div>
                <div style={{width: "30%", margin: "auto" }}>
                    <img src='./images/img12.jpg' style={{width: "100%"}} />
                </div>
                <div style={{width: "30%", margin: "auto" }}>
                    <img src='./images/img13.jpg' style={{width: "100%"}} />
                </div>
                <div style={{width: "30%", margin: "auto" }}>
                    <img src='./images/img14.jpg' style={{width: "100%"}} />
                </div>
                <div style={{width: "30%", margin: "auto" }}>
                    <img src='./images/img15.jpg' style={{width: "100%"}} />
                </div>
            </div>
         </SRLWrapper>
    )
}